bash edge-generator.sh
bash case-generator.sh
bash peaks-generator.sh
bash vaccinated-count-generator.sh
bash vaccination-population-ratio-generator.sh
bash vaccine-type-ratio-generator.sh
bash vaccinated-ratio-generator.sh
bash complete-vaccination-generator.sh