python anomaly_endsem.py
